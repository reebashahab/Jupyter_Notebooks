####################################################################################################
# Import needed modules.
####################################################################################################
# The shutil module helps you automate copying files and directories.
# The csv module implements classes to read and write tabular data in CSV format.
# The OS module in Python provides a way of using operating system dependent functionality.
# Use getpass to get username.
import os, csv, shutil, getpass

# Import only the datetime function from the datetime module.
from datetime import datetime

####################################################################################################
# Define variables.
####################################################################################################
# Ask for number of samples/accession ids.
num_samples = raw_input("Number of samples? (<= 46) ")

# If not a number, prompt user to try again.
while num_samples.isdigit() == False or int(num_samples) > 46:
	num_samples = raw_input("Please enter a number <= 46: ")
	
# Ask users if the length of their accession ids matters.
str_len = raw_input("Does the length of the accession ids matter? Y/N: ")

# If the user enters anything other than Y/N, prompt user to try again.
# Note, the script only cares whether the first letter is 'y' or 'n'.
# Not case-sensitive.
while str_len[0].lower() != "y" and str_len[0].lower() != "n":
	str_len = raw_input("Y/N, only please: ")

# If the length of the accession ids matters, ask for and store the desired length of string.
# Otherwise, store the number 0.
if str_len[0].lower() == "y":
	len_char = int(raw_input("Enter desired length of string? "))
else:
	len_char = 0
	
# Ask user what to letters to start each sample with. i.e. "RS1, RS2..."
# Convert input to be all uppercase.
starting_string = raw_input("Starting characters of samples? ").upper()

# Ask user to enter product.
# Convert input to be all uppercase.
product = raw_input("'Guardant 360', 'IVD', or 'OMNI': ").upper()

# Ask for Elution Plate ID.
Elution_Plate_ID = raw_input("Elution Plate ID: ")

# Ask for Tube Rack ID.
Tube_Rack_ID = raw_input("Tube Rack ID: ")

# Ask for TS Plate ID.
TS_Plate_ID = raw_input("TS Plate ID: ")

# Define file path for templates, create new subfolder, define new subfolder path.
source_path = "/home/rshahab/ACS Test File Generation" + "/_donotopen/"
new_subfolder = os.makedirs("/home/rshahab/ACS Test File Generation/" + product + "_" + getpass.getuser() + "_Test_Files_" + datetime.today().strftime("%y%m%d_%I-%M-%S"))
new_subfolder_path = "/home/rshahab/ACS Test File Generation/" + product + "_" + getpass.getuser() + "_Test_Files_" + datetime.today().strftime("%y%m%d_%I-%M-%S") + "/"

####################################################################################################
# Define functions.	
####################################################################################################
# Create function for rewriting data in-place.
# Requires filename, old text, and new text/text to replace with.
def inplace_change(filename, old_string, new_string):
	# Open file as read-only.
	with open(filename, "rb") as f:
		# Store as string.
		read_file = f.read()
	# Open file in writeable state.
	with open(filename, "wb") as f:
		# Replace contents of previously saved string.
		read_file_string = read_file.replace(old_string, new_string)
		# Write saved string to file.
		f.write(read_file_string)

# Create function to edit/replace string in file.
def edit_file(base_file, starts_with, plate_id, old_string, new_string):
	# Define base filepath.
	base_file_path = source_path + base_file
	# Define new filepath.
	new_file_path = new_subfolder_path + starts_with + plate_id + ".csv"
	# Copy the contents of the base file to the new file.
	shutil.copyfile(base_file_path,new_file_path)
	
	# Change directory.
	os.chdir(new_subfolder_path)

	# Open the new file as read-only.
	file_to_edit = open(starts_with + plate_id + ".csv", "rb")
	
	# Read new file.
	file_to_edit = csv.reader(file_to_edit, delimiter=",")
	
	# Skip header row.
	file_to_edit.next()
	
	# For each row in the new file that needs editing,
	# use the inplace_change function to edit text.
	for row in file_to_edit:
		# make the replacement for each line in lookup file
		inplace_change(starts_with + plate_id + ".csv", old_string, new_string)
	
	# Print confirmation message.	
	print starts_with + plate_id + ".csv is ready."

# Create function to generate a new import_samples.csv.	
def import_samples():
	# Create file in following directory. Name will be "importSamplesYYMMDD HHMMSS.csv".
	new_file = new_subfolder_path + "import_samples" + ".csv"

	# Open the newly created file and indicate you will write strings to the file.
	f = open(new_file, "wb")

	# Set the column titles.
	column_header = "AccessionId,Gender,SampleType,Project,Product\n"

	# Write the column titles.
	f.write(column_header)

	# For the number of samples indicated above, write the following in each row.
	# Note, values for Gender, SampleType, Project will be defaults.
	# 
	for sample in range(1,int(num_samples)+1):
		# Set variables.		
		# Det. the desired length of string - length of the starting string.
		# Number will reveal remaining characters to work with.
		num = len_char - len(starting_string)
		# If the desired length of string is > 0 (matters), set the AccessionId to equal the starting string + the sample number padded with 0s to get desired length of string.
		if len_char > 0:
			AccessionId = str(starting_string) + str(sample).zfill(num)
		# If the desired length of string = 0 (doesn't matter), set the AccessionId to equal the starting string + the sample number.
		else:
			AccessionId = str(starting_string) + str(sample)
		Gender = "Female"
		SampleType = "Clinical"
		Project = "testrun"
		Product = product
	
		# Create row string.
		row = AccessionId + "," + Gender + "," + SampleType + "," + Project + "," + Product + "\n"
	
		# write row string.
		f.write(row)

	# Provide confirmation message for user.	
	print "import_samples" + ".csv is ready."
	
# Create function to 
def edit_QS_XML_file(base_file, plate_id):
	# Create empty lists for old and new sample/accession ids.
	old_sample_ids = []
	new_sample_ids = []

	# Depending on number of samples desired by user, populate old_sample_ids with values. Will be our keys later on in our key-value pair.
	for num in range(1,int(num_samples)+1):
		num = str(num)
		if len(num) == 1:
			num_pad = num.zfill(2)
			num_pad = "Sample_" + str(num_pad)
			old_sample_ids.append(num_pad)
		else:
			num = "Sample_" + str(num)
			old_sample_ids.append(num)

	# Depending on number of samples desired by user, populate new_sample_ids with values. Will be our values later on in our key-value pair.
	# Same as above, ff the desired length of string is > 0 (matters), set the AccessionId to equal the starting string + the sample number padded with 0s to get desired length of string.
	for sample in range(1,int(num_samples)+1):
		sample = str(sample)
		num = len_char - len(starting_string)
		if len_char > 0:
			sample = str(starting_string) + str(sample).zfill(num)
		else:
			sample = str(starting_string) + str(sample)
		new_sample_ids.append(sample)

	# Pair items in lists, and transform into a dictionary with key-value pairs.
	dictionary = dict(zip(old_sample_ids, new_sample_ids))
	
	# Define base filepath.
	base_file_path = source_path + base_file
	# Define new filepath.
	new_file_path = new_subfolder_path + plate_id + ".xml"
	# Copy the contents of the base file to the new file.
	shutil.copyfile(base_file_path,new_file_path)
	
	for k, v in dictionary.items():
		inplace_change(new_file_path,k,v)
	
	print plate_id + ".xml is ready."
	
####################################################################################################
# Call functions.
####################################################################################################
# Create import samples CSV.
import_samples()

# Create XML file for QS.
edit_QS_XML_file("base_DONOTEDIT.xml", Elution_Plate_ID)

# Create a capper-decapper file for even scans.
edit_file("Even_Capper-Decapper_File_Template.csv", "Capper_File_", Tube_Rack_ID, "Tube Rack ID", Tube_Rack_ID) 

# Create a capper-decapper file for odd scans.
edit_file("Odd_Capper-Decapper_File_Template.csv", "Decapper_File_", Tube_Rack_ID, "Tube Rack ID", Tube_Rack_ID) 

# Create a compactPeakTable file.
edit_file("Template_compactPeakTable.csv", "PeakTable_", TS_Plate_ID, "Tube Rack ID", Tube_Rack_ID)

# Create a compactRegionTable file.
edit_file("Template_compactRegionTable.csv", "RegionTable_", TS_Plate_ID, "Tube Rack ID", Tube_Rack_ID)

print "See, " + new_subfolder_path